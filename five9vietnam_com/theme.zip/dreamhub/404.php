<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package dreamhub
 */

get_header();
?>

<?php global $dreamhub_opt; ?>

	<div class="breadcumb-area">
		<div class="container">
			<div class="text-wrapper">
				<h2>404</h2>
				<?php dreamhub_breadcrumbs(); ?>
			</div>
		</div>
	</div>

	<div class="four-zero-four">
		<div class="container">
			<main id="primary" class="site-main">

				<section class="error-404 not-found">
					<header class="page-header">
						<?php if( !empty($dreamhub_opt['404_info']) ){ ?>
							<h1 class="page-title"><?php echo $dreamhub_opt['404_info']; ?></h1>
						<?php }else{ ?>
							<h1 class="page-title">Oops! That page can’t be found.</h1>
						<?php } ?>
					</header>

					<div class="page-content">
						<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'dreamhub' ); ?></p>
					</div>
				</section>

			</main>
		</div>
	</div>

<?php
get_footer();
