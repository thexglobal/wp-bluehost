<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dreamhub
 */

?>

<?php global $dreamhub_opt; ?>




	<footer id="colophon" class="site-footer">

		<?php if( !empty($dreamhub_opt['footer_widget_toggle']) && $dreamhub_opt['footer_widget_toggle']==true ){ ?>

		<?php $footer_column_count = $dreamhub_opt['widget_column_count']; ?>
		<?php if( 0 != $footer_column_count ) { ?>

		<div class="footer-widget">
			<div class="container">
				<div class="row">

				<?php if( '' == $footer_column_count ){$footer_column_count = 4;}
				$footer_sidebar_class = floor( 12/$footer_column_count ); ?>

				<?php for( $footer = 1; $footer <= $footer_column_count; $footer++ ) { ?>

					<?php if ( is_active_sidebar( 'footer-' . $footer ) ) { ?>

					<div class="col-lg-<?php echo esc_attr( $footer_sidebar_class ); ?>">
						<?php dynamic_sidebar( 'footer-'. $footer ); ?>
					</div>

					<?php } ?>

				<?php } ?>

				</div>
			</div>
		</div>

		<?php } ?>

		<?php } ?>	

		<div class="copyright">
			<div class="container">
				<div class="copyright-wrapper">
					<?php if(!empty($dreamhub_opt['footer_copyright_style']) && $dreamhub_opt['footer_copyright_style']=="copy_s2"){ ?>
					<div class="row align-items-center">
						<div class="col-md-6">
							<div class="copyright-text">
								<p><?php echo $dreamhub_opt['copyright-text']; ?></p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="copyright-menu">
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'menu-2',
									'menu_id'        => 'copyright-menu',
									'fallback_cb' => false,
								)
							);
							?>
							</div>
						</div>
					</div>
					<?php }elseif(!empty($multilen_opt['footer_copyright_style']) && $multilen_opt['footer_copyright_style']=="copy_s1"){ ?>
						<div class="copyright-text" style="text-align: center;">
							<p><?php echo $multilen_opt['copyright-text']; ?></p>
						</div>
					<?php }else{?>
						<div class="copyright-text" style="text-align: center;">
							<p>Copyright © dreamhub all rights reserved.</p>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
