<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package dreamhub
 */

?>

<?php global $dreamhub_opt; ?>

<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'dreamhub' ); ?></a>

	<header id="masthead" class="site-header">

		
		<?php if( !empty($dreamhub_opt['header_top_toggle']) && $dreamhub_opt['header_top_toggle']==true ){ ?>

		<?php  $dreamhub_header_topa = get_post_meta( get_the_ID(),'_dreamhub_dreamhub_header_topa', true );  ?>
		<?php if( empty($dreamhub_header_topa) || $dreamhub_header_topa==1){ ?>

		<div class="top-bar">
			<div class="<?php if ( get_post_meta( get_the_ID(), 'full_header', 1 ) ){ echo "container-fluid"; }else{ echo "container"; } ?>">
				<div class="text-wrapper">
					<ul class="text-left">
						<li class="phone">
							<i class="fa fa-phone" aria-hidden="true"></i>
							<a href="tel:<?php echo $dreamhub_opt['top_phone']; ?>"><?php echo $dreamhub_opt['top_phone']; ?></a>
						</li>
						<li class="email">
							<a href="<?php echo esc_url($dreamhub_opt['top_link1_url']); ?>"><?php echo $dreamhub_opt['top_link1_text']; ?></a>
						</li>
						<li class="address">
							<a href="<?php echo esc_url($dreamhub_opt['top_link2_url']); ?>"><?php echo $dreamhub_opt['top_link2_text']; ?></a>
						</li>
					</ul>
					<div class="text-right">
						<ul>
							<?php 
								foreach($dreamhub_opt['top_social_icons'] as $key=>$value ) { 
										
									if($value != ''){
										echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank"><i class="fa fa-'.esc_attr($key).'"></i></a></li>';
									}
								}
							?>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<?php } ?>
		<?php } ?>






		<?php  $dreamhub_header_style = get_post_meta( get_the_ID(),'_dreamhub_dreamhub_header_style', true ); ?>

		<?php if( empty($dreamhub_header_style) ){ ?>

		<div class="main-menu <?php if ( get_post_meta( get_the_ID(), 'transparent_menu', 1 ) ){ echo "transparent-menu"; } ?>">
			<div class="<?php if ( get_post_meta( get_the_ID(), 'full_header', 1 ) ){ echo "container-fluid"; }else{ echo "container"; } ?>">
				<div class="manu-wrapper">

					<div class="site-branding">
						<?php

						if( has_custom_logo() && ( empty($dreamhub_opt['default_logo']['url']) ) ){

							the_custom_logo();

						}elseif( get_post_meta( get_the_ID(), 'transparent_menu', 1 ) ){
							?>

							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link"><img src="<?php echo $dreamhub_opt['transparent_logo']['url']; ?>" alt=""></a>

							<?php

						}elseif( !empty($dreamhub_opt['default_logo']['url']) ){
							?>

							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link"><img src="<?php echo $dreamhub_opt['default_logo']['url']; ?>" alt=""></a>

							<?php

						}else{

							?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
							<?php
							
							$dreamhub_description = get_bloginfo( 'description', 'display' );
							if ( $dreamhub_description || is_customize_preview() ) :
								?>
								<p class="site-description"><?php echo $dreamhub_description; ?></p>
							<?php endif; ?>

						<?php } ?>
					</div>
						
					<nav id="site-navigation" class="main-navigation">
						<div class="menu-toggle"><i class="fa fa-bars"></i></div>
						<div class="header-nav">
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'menu-1',
								'menu_id'        => 'primary-menu',
								'menu_class'        => 'menu-ul',
								// 'walker' => new WalkerNav()
							)
						);
						?>

						<?php if ( $amenities = get_post_meta( get_the_ID(), '_dreamhub_menu_elements', true ) ) {

							foreach ( $amenities as $amenity ) {

								if( $amenity == 'check1' ){


								?>
								<div class="search">
									<div class="search-icon">
										<i class="fa fa-search" aria-hidden="true"></i>
									</div>
									
									<div class="search-form">
										<div class="form-wrapper">
										<form action="#">
											<input type="text" placeholder="Type Your Keyword">
											<button type="submit"><i class="fa fa-search"></i></button>
										</form>
										</div>
									</div>
								</div>

								<?php


								}elseif($amenity == 'check2'){
									echo '<div class="menu-button"><a class="button" href="'.esc_url($dreamhub_opt['button_link']).'"> '.$dreamhub_opt['button_text'].' </a></div>';

								}

							}

						} ?>

						</div>
						
					</nav>
						
				</div>
			</div>
		</div>

		<?php }elseif( $dreamhub_header_style == 1 ){ ?>

			<h3>Style one is not designed.</h3>

		<?php }elseif( $dreamhub_header_style == 2 ){ ?>

			<h3>Style two is not designed.</h3>

		<?php } ?>


	</header>




