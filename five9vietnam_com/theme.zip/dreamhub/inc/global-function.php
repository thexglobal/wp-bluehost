<?php

//dreamhub comment form

if(!function_exists('dreamhub_comments_form')){
	function dreamhub_comments_form($default){
			$default['author'] = '<div  class="comment_forms from-area"><div  class="comment_forms_inner">
			
			<div class="comment_field"><div class="row"><div class="col-md-6 form-group">
				<input id="name" class="form-control" name="author" type="text" placeholder="'.esc_attr('Your Name','dreamhub').'"/>
			</div>';

			$default['email'] = '
			<div class="col-md-6 form-group">
				<input id="email" class="form-control"  name="email" type="text" placeholder="'.esc_attr(' Email','dreamhub').'"/>
			</div></div>';	
			$default['phone'] = '<div class="row">
			<div class="col-md-6 form-group">
				<input id="phone" class="form-control"  name="phone" type="text" placeholder="'.esc_attr('Phone','dreamhub').'"/>
			</div>';

			$default['title'] = '
			<div class="col-md-6 form-group">
				<input id="title" class="form-control" name="url" type="text" placeholder="'.esc_attr('Your Website','dreamhub').'"/>
			</div> </div></div>';	
			$default['url']='';
			$default['message'] ='<div class="comment_field"><div class="form-group"><textarea name="comment" id="comment" class="form-control" cols="30" rows="6" placeholder="'.esc_attr(' Your comment...','dreamhub').'"></textarea></div></div></div></div>';

		return $default;
	}
}
add_filter('comment_form_default_fields','dreamhub_comments_form');


if(!function_exists('dreamhub_form_default')){
	function dreamhub_form_default($default_info){
		if(!is_user_logged_in()){
			$default_info['comment_field'] = '';
		}else{
			$default_info['comment_field'] = '<div  class="comment_forms"><div  class="comment_forms_inner"> <div class="comment_field row"><div class="col-md-12 form-group"><label for="comment">'.esc_html__('Comment','dreamhub').'<em>*</em></label><textarea name="comment" id="comment" class="form-control" cols="30" rows="6" placeholder="'.esc_attr('Your comment...','dreamhub').'"></textarea></div></div> </div></div>';
		}

		$default_info['submit_button'] = '<button class="wpcf7-submit button" type="submit">'.esc_html__('Post Comment','dreamhub').'<i class="fa fa-angle-right"></i></button>';
		$default_info['submit_field'] = '%1$s %2$s';
		$default_info['comment_notes_before'] = ' ';
		$default_info['title_reply'] = esc_html__('Leave Comment','dreamhub');
		$default_info['title_reply_before'] = '<div class="commment_title"><h3> ';
		$default_info['title_reply_after'] = '</h3></div> ';

		return $default_info;
	}
}
add_filter('comment_form_defaults','dreamhub_form_default');


// Pagination

if( !function_exists( 'dreamhub_pagination' ) ) {
	function dreamhub_pagination( $args = NULL , $wrapper = 'div', $wrapper_class = 'paginations' ) {

		global $wp_query, $paged;

		// Get the current page
		if( empty($paged ) ) $paged = ( get_query_var('page') ? get_query_var('page') : 1 );

		// Set a large number for the 'base' argument
		$big = 99999;

		// Get the correct post query
		if( !isset( $args[ 'query' ] ) ){
			$use_query = $wp_query;
		} else {
			$use_query = $args[ 'query' ];
		} ?>

		<<?php echo esc_html($wrapper); ?> class="<?php echo esc_html($wrapper_class); ?>">
			<?php echo paginate_links( array(
				'base' => str_replace( $big, '%#%', get_pagenum_link($big) ),
				'prev_next' => true,
				'mid_size' => ( isset( $args[ 'range' ] ) ? $args[ 'range' ] : 5 ) ,
				'prev_text' => '<i class="fa fa-angle-double-left"></i>',
				'next_text' => '<i class="fa fa-angle-double-right"></i>',
				'type' => 'list',
				'current' => $paged,
				'total' => $use_query->max_num_pages
			) ); ?>
		</<?php echo esc_html($wrapper); ?>>
	<?php }
}


