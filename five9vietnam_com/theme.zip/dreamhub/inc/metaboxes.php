<?php




	function dreamhub_metabox() {

		$prefix = '_dreamhub_';

		//header metabox
	 	$page_heading_style = new_cmb2_box( array(
		'id'            => $prefix . 'header_style_option',
		'title'         => esc_html__( 'Header Style Option', 'dreamhub' ),
		'object_types'  => array( 'page','post' ), // Post type
		'priority'   => 'high',
		) );
	

	
		$page_heading_style->add_field( array(
			'name'    => esc_html__('Top Bar Style ','dreamhub'),
			'id'      => $prefix . 'dreamhub_header_topa',
			'type'    => 'radio_inline',
			'options' => array(
			'1' => esc_html__( 'Show Top Bar in this page', 'dreamhub' ),
			'2'   => esc_html__( 'Hide Top Bar in this page', 'dreamhub' ),
			),
			'default' =>'2',
		) );
		$page_heading_style->add_field( array(
			'name'    => esc_html__('Header Style','dreamhub'),
			'id'      => $prefix . 'dreamhub_header_style',
			'show_option_none' => true,
			'desc'   => esc_html__( 'Choose a style', 'dreamhub' ), 			
			'type'    => 'select',
			'options' => array(
				'1' => esc_html__( 'Style One', 'dreamhub' ),				
				'2' => esc_html__( 'Style Two', 'dreamhub' ),
			),
		) );

		$page_heading_style->add_field( array(
			'name' => 'Add menu elements',
			'id' => $prefix . 'menu_elements',
			'type' => 'multicheck_inline',
			'select_all_button' => false,
			'options' => array(
				'check1' => 'Search Icon',
				'check2' => 'Button',
			)
		) );

		$page_heading_style->add_field( array(
			'name' => 'Transparent Menu',
			'desc' => 'Active',
			'id'   => 'transparent_menu',
			'type' => 'checkbox',
		) );
		$page_heading_style->add_field( array(
			'name' => 'Full Width Header',
			'desc' => 'Active',
			'id'   => 'full_header',
			'type' => 'checkbox',
		) );

		
		//breadcrumb metabox
		$page_breadcrumb = new_cmb2_box( array(
		   'id'            => $prefix . 'pageid1',
		   'title'         => esc_html__( 'Breadcumb Option', 'dreamhub' ),
		   'object_types'  => array( 'post','page','em_event','em_portfolio' ), // Post type
		   'priority'   => 'high',
		) );
		
		$page_breadcrumb->add_field( array(
			'name'    => esc_html__('Breadcrumb','dreamhub'),
			'id'      => $prefix . 'breadcrumbs',
			'type'    => 'radio_inline',
			'options' => array(
			'0' => esc_html__( 'Show breadcrumb', 'dreamhub' ),
			'1'   => esc_html__( 'Hide breadcrumb', 'dreamhub' ),
			),
			'default' =>0,
		) );
		$page_breadcrumb->add_field( array(
			'name'    => esc_html__('Breadcrumb Title','dreamhub'),
			'id'      => $prefix . 'breadcrumb_title',
			'type'    => 'radio_inline',
			'options' => array(
				'show_title' => esc_html__( 'Show Title', 'dreamhub' ),
				'hide_title'   => esc_html__( 'Hide Title', 'dreamhub' ),
			),
			'default' =>'show_title',
		) );    
		$page_breadcrumb->add_field(array(
			'name' => esc_html__( 'Background Image', 'dreamhub' ),
			'id'   => $prefix .'bg_image',
			'desc' => esc_html__( 'insert image here', 'dreamhub' ),  
			'type' => 'file',
		) );  

		$page_breadcrumb->add_field( array(
			'name'             => esc_html__('Text Transform','dreamhub'),
			'desc'             => esc_html__('Select an option','dreamhub'),
			'id'   => $prefix .'page_text_transform',
			'type'             => 'select',
			'show_option_none' => true,
			'options'          => array(
				'lowercase' => esc_html__( 'Transform lowercase', 'dreamhub' ),
				'uppercase'   => esc_html__( 'Transform uppercase', 'dreamhub' ),
				'capitalize'     => esc_html__( 'Transform capitalize', 'dreamhub' ),
			),
		) );	

		//footer metabox
	 	$page_footer_style = new_cmb2_box( array(
		'id'            => $prefix . 'footer_style_option',
		'title'         => esc_html__( 'Footer Style Option', 'dreamhub' ),
		'object_types'  => array( 'page','post' ), // Post type
		'priority'   => 'high',
		) );

		$page_footer_style->add_field( array(
			'name'    => esc_html__('Footer Style','dreamhub'),
			'id'      => $prefix . 'dreamhub_footer_style',
			'show_option_none' => true,
			'desc'   => esc_html__( 'Choose a style', 'dreamhub' ), 			
			'type'    => 'select',
			'options' => array(
				'1' => esc_html__( 'One', 'dreamhub' ),				
				'2' => esc_html__( 'Two', 'dreamhub' ),
			),
		) );

		//Testimonial
		$testimonial = new_cmb2_box( array(
			'id'            => $prefix . 'em_testimonial',
			'title'         => esc_html__( 'Testimonial Option', 'dreamhub' ),
			'object_types'  => array( 'em_testimonial' ), // Post type
			'priority'   => 'high',
		) );
			$testimonial->add_field( array(
				'name'       => esc_html__( 'Degignation', 'dreamhub' ),
				'desc'       => esc_html__( 'insert Degignation here', 'dreamhub' ),
				'id'         => $prefix . 'testi_deg',
				'type'       => 'text',
			) );	

		//Case Study
		$casestudy = new_cmb2_box( array(
			'id'            => $prefix . 'em_case_study',
			'title'         => esc_html__( 'Case Study Option', 'dreamhub' ),
			'object_types'  => array( 'em_case_study' ), // Post type
			'priority'   => 'high',
		) );
			$casestudy->add_field( array(
				'name'       => esc_html__( 'Case Study Description', 'dreamhub' ),
				'desc'       => esc_html__( 'Description', 'dreamhub' ),
				'id'         => $prefix . 'casedesc',
				'type'       => 'wysiwyg',
			) );	
							
				
				
			//===================================
			//Portfolio Metaboxes
			//===================================  

			$portfolio = new_cmb2_box( array(
				'id'            => $prefix . 'portfolio',
				'title'         => esc_html__( 'Portfolio Option', 'dreamhub' ),
				'object_types'  => array( 'em_portfolio', ), // Post type
				'priority'   => 'high',
			) );
			$portfolio->add_field( array(
				'name'       => esc_html__( 'Portfolio Description', 'dreamhub' ),
				'desc'       => esc_html__( 'Description', 'dreamhub' ),
				'id'         => $prefix . 'portdesc',
				'type'       => 'wysiwyg',
			) );				
			
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide All Option','dreamhub'),			  
			   'id'      => $prefix . 'saloption',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_alshow' => esc_html__( 'Show', 'dreamhub' ),
				'm_alhide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_alhide',
			  ) );			
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Popup Image','dreamhub'),			  
			   'id'      => $prefix . 'siimagepop',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_ishow' => esc_html__( 'Show', 'dreamhub' ),
				'm_ihide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_ishow',
			  ) );
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Link Page','dreamhub'),			  
			   'id'      => $prefix . 'sllink',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_lshow' => esc_html__( 'Show', 'dreamhub' ),
				'm_lhide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_lshow',
			  ) );				  
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Popup Youtube','dreamhub'),			  
			   'id'      => $prefix . 'shyoutub',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_yshow' => esc_html__( 'Show', 'dreamhub' ),
				'm_yhide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_yhide',
			  ) );				
			   $portfolio->add_field( array(
				'name'       => esc_html__( 'Youtube Video', 'dreamhub' ),
				'desc'       => esc_html__( 'insert video link. ex-https://youtu.be/OJ9ejTy4J98', 'dreamhub' ),
				'id'         => $prefix . 'pyoutube',
				'type'       => 'text_url',
			   ) );
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Popup Vimeo','dreamhub'),			  
			   'id'      => $prefix . 'svvimeo',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_vshow' => esc_html__( 'Show', 'dreamhub' ),
				'm_vhide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_vhide',
			  ) );				   
			   $portfolio->add_field( array(
				'name'       => esc_html__( 'Vimeo Video', 'dreamhub' ),
				'desc'       => esc_html__( 'insert video link. ex-https://youtu.be/OJ9ejTy4J98', 'dreamhub' ),
				'id'         => $prefix . 'pvimeo',
				'type'       => 'text_url',
			   ) );		   

			  $portfolio->add_field( array(
			   'name'    => esc_html__('Select Multi Gellary','dreamhub'),			  
			   'id'      => $prefix . 'm_g_image_pop',
			   'type'    => 'radio_inline',
			   'options' => array(
				'm_gshow' => esc_html__( 'Show', 'dreamhub' ),
				'm_ghide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'m_ghide',
			  ) );				   
				$portfolio->add_field( array(
					'name'       => esc_html__( 'Multiple Gellary Image', 'dreamhub' ),
					'desc'       => esc_html__( 'insert multiple gellary image here for single page', 'dreamhub' ),
					'id'         => $prefix . 'pgellaryu',
					'type'       => 'file_list',
				) );
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Title','dreamhub'),			  
			   'id'      => $prefix . 'pshow_title',
			   'type'    => 'radio_inline',
			   'options' => array(
				'ptitle_show' => esc_html__( 'Show', 'dreamhub' ),
				'ptitle_hide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'ptitle_show',
			  ) );					
			  $portfolio->add_field( array(
			   'name'    => esc_html__('Show/Hide Category','dreamhub'),			  
			   'id'      => $prefix . 'pshow_cat',
			   'type'    => 'radio_inline',
			   'options' => array(
				'pcat_show' => esc_html__( 'Show', 'dreamhub' ),
				'pcat_hide'   => esc_html__( 'Hide', 'dreamhub' ),
			   ),
			   'default' =>'pcat_show',
			  ) );	
		//===================================
		//Pricing table metabox
		//===================================
		$pricing = new_cmb2_box( array(
			'id'            => $prefix . 'pricing',
			'title'         => esc_html__( 'Price Option', 'dreamhub' ),
			'object_types'  => array( 'em_pricing', ), // Post type
			'priority'   => 'high',
		) );
				$pricing->add_field( array(
					'name'       => esc_html__( 'Price Currency', 'dreamhub' ),
					'desc'       => esc_html__( 'insert Currency here e.g $', 'dreamhub' ),
					'id'         => $prefix . 'currency',
					'type'       => 'text',
				) );	
				$pricing->add_field( array(
					'name'       => esc_html__( 'Price Amount', 'dreamhub' ),
					'desc'       => esc_html__( 'insert Amount here', 'dreamhub' ),
					'id'         => $prefix . 'price_amount',
					'type'       => 'text',
				) );	
				$pricing->add_field( array(
					'name'       => esc_html__( 'Price Delay', 'dreamhub' ),
					'desc'       => esc_html__( 'insert Year, Month, Week or Day here', 'dreamhub' ),
					'id'         => $prefix . 'day',
					'type'       => 'text',
				) );						
				$pricing->add_field( array(
					'name'       => esc_html__( 'pricing content', 'dreamhub' ),
					'desc'       => esc_html__( 'insert pricing Item', 'dreamhub' ),
					'id'         => $prefix . 'pricing_item_loop',
					'type'       => 'text',
					'repeatable'      => true,
				) );
				$pricing->add_field( array(
					'name' => esc_html__( 'Button Text', 'dreamhub' ),
					'desc' => esc_html__( 'Insert Text Here', 'dreamhub' ),
					'id'   => $prefix . 'button_text',
					'type' => 'text',
				) );					
				$pricing->add_field( array(
					'name' => esc_html__( 'Button Link', 'dreamhub' ),
					'desc' => esc_html__( 'Insert register Link', 'dreamhub' ),
					'id'   => $prefix . 'button_link',
					'type' => 'text_url',
				) );
				$pricing->add_field( array(
					'name' => esc_html__( 'Active Class', 'dreamhub' ),
					'desc' => esc_html__( 'Add Active Class here "active"', 'dreamhub' ),
					'id'   => $prefix . 'active',
					'type' => 'text',
				) );

				
				
		//post tab metabox
			$emtab = new_cmb2_box( array(
				'id'            => $prefix . 'em_tab',
				'title'         => esc_html__( 'Tab Option', 'dreamhub' ),
				'object_types'  => array( 'em_tab' ), // Post type
				'priority'   => 'high',
			) );

				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Menu Name', 'dreamhub' ),
					'desc'       => esc_html__( 'insert tab menu here', 'dreamhub' ),
					'id'         => $prefix . 'em_tab_menu',
					'type'       => 'text',
				) );					
									
				$emtab->add_field(array(
					'name' => esc_html__( 'Tab Menu Image', 'dreamhub' ),
					'id'   => $prefix .'em_tab_image',
					'desc'       => esc_html__( 'insert image here', 'dreamhub' ),  
					'type' => 'file',
				) );
				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Menu Active', 'dreamhub' ),
					'desc'       => esc_html__( 'must be set "active in" class into one post from all post, for active tab item', 'dreamhub' ),
					'id'         => $prefix . 'em_tab_active',
					'type'       => 'text',
				) );
				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Icon Name', 'dreamhub' ),
					'desc'       => esc_html__( 'Type Your favorite Font awesome Icon name', 'dreamhub' ),
					'id'         => $prefix . 'em_tab_icon',
					'type'       => 'text',
				) );
				
					
				
				
								
			//slider table metabox
				$slider = new_cmb2_box( array(
					'id'            => $prefix . 'dreamhub_slider',
					'title'         => esc_html__( 'Slider Option', 'dreamhub' ),
					'object_types'  => array( 'em_slider', ), // Post type
					'priority'   => 'high',
				) );
	
	
			$slider->add_field( array(
				'name'       => esc_html__( 'Title', 'dreamhub' ),
				'desc'       => esc_html__( 'insert title here. for highlight text use <span> ex-<span>Design</span>', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_title',
				'type'       => 'textarea_small',
			) );

			$slider->add_field( array(
				'name'    => esc_html__('Title Animate','dreamhub'),
				'id'      => $prefix . 'em_aimate_title',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'dreamhub' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'dreamhub' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'dreamhub' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'dreamhub' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'dreamhub' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'dreamhub' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'dreamhub' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'dreamhub' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'dreamhub' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'dreamhub' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'dreamhub' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'dreamhub' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'dreamhub' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'dreamhub' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'dreamhub' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'dreamhub' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'dreamhub' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'dreamhub' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'dreamhub' ),				
					'rollIn' => esc_html__( 'rollIn', 'dreamhub' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'dreamhub' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'dreamhub' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'dreamhub' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'dreamhub' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'dreamhub' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'dreamhub' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'dreamhub' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'dreamhub' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'dreamhub' ),				
				),
				'default' =>'slideInRight',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Title Animate Duration','dreamhub'),
				'id'      => $prefix . 'em_durations_title',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Title Animate Delay','dreamhub'),
				'id'      => $prefix . 'em_dealy_title',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'dreamhub' ),							
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'0',
			) );		

		
		
		
			
			$slider->add_field( array(
				'name'       => esc_html__( 'Sub Title', 'dreamhub' ),
				'desc'       => esc_html__( 'insert sub-title here. for highlight text use <span> ex-<span>website</span>', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_subtitle',
				'type'       => 'textarea_small',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate','dreamhub'),
				'id'      => $prefix . 'em_aimate_subtitle',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'dreamhub' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'dreamhub' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'dreamhub' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'dreamhub' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'dreamhub' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'dreamhub' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'dreamhub' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'dreamhub' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'dreamhub' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'dreamhub' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'dreamhub' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'dreamhub' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'dreamhub' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'dreamhub' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'dreamhub' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'dreamhub' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'dreamhub' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'dreamhub' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'dreamhub' ),				
					'rollIn' => esc_html__( 'rollIn', 'dreamhub' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'dreamhub' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'dreamhub' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'dreamhub' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'dreamhub' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'dreamhub' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'dreamhub' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'dreamhub' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'dreamhub' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'dreamhub' ),				
				),
				'default' =>'slideInRight',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate Duration','dreamhub'),
				'id'      => $prefix . 'em_durations_subtitle',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate Delay','dreamhub'),
				'id'      => $prefix . 'em_dealy_subtitle',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'dreamhub' ),							
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'0',
			) );				
			$slider->add_field( array(
				'name'       => esc_html__( 'Content', 'dreamhub' ),
				'desc'       => esc_html__( 'insert content here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_textarea',
				'type'       => 'textarea',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Content Animate','dreamhub'),
				'id'      => $prefix . 'em_aimate_content',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'dreamhub' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'dreamhub' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'dreamhub' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'dreamhub' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'dreamhub' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'dreamhub' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'dreamhub' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'dreamhub' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'dreamhub' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'dreamhub' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'dreamhub' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'dreamhub' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'dreamhub' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'dreamhub' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'dreamhub' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'dreamhub' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'dreamhub' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'dreamhub' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'dreamhub' ),				
					'rollIn' => esc_html__( 'rollIn', 'dreamhub' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'dreamhub' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'dreamhub' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'dreamhub' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'dreamhub' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'dreamhub' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'dreamhub' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'dreamhub' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'dreamhub' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'dreamhub' ),				
				),
				'default' =>'slideInRight',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Content Animate Duration','dreamhub'),
				'id'      => $prefix . 'em_durations_content',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'3',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Content Animate Delay','dreamhub'),
				'id'      => $prefix . 'em_dealy_content',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'dreamhub' ),							
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'0',
			) );				
			
			$slider->add_field( array(
				'name'       => esc_html__( 'Button Text 1', 'dreamhub' ),
				'desc'       => esc_html__( 'insert button text here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_btn1',
				'type'       => 'text',
			) );
			$slider->add_field( array(
				'name'       => esc_html__( 'Slide Image', 'dreamhub' ),
				'desc'       => esc_html__( 'insert single slide image here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_img',
				'type'       => 'file',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Image Animate','dreamhub'),
				'id'      => $prefix . 'em_aimate_image',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'dreamhub' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'dreamhub' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'dreamhub' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'dreamhub' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'dreamhub' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'dreamhub' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'dreamhub' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'dreamhub' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'dreamhub' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'dreamhub' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'dreamhub' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'dreamhub' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'dreamhub' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'dreamhub' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'dreamhub' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'dreamhub' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'dreamhub' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'dreamhub' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'dreamhub' ),				
					'rollIn' => esc_html__( 'rollIn', 'dreamhub' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'dreamhub' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'dreamhub' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'dreamhub' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'dreamhub' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'dreamhub' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'dreamhub' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'dreamhub' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'dreamhub' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'dreamhub' ),				
				),
				'default' =>'slideInRight',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Image Animate Duration','dreamhub'),
				'id'      => $prefix . 'em_durations_image',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Image Animate Delay','dreamhub'),
				'id'      => $prefix . 'em_dealy_image',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'dreamhub' ),							
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'0',
			) );		

			
			
			$slider->add_field( array(
				'name'       => esc_html__( 'Button url 1', 'dreamhub' ),
				'desc'       => esc_html__( 'insert button text url here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_btn1utl',
				'type'       => 'text_url',
			) );			
			$slider->add_field( array(
				'name'       => esc_html__( 'Button Text 2', 'dreamhub' ),
				'desc'       => esc_html__( 'insert button text here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_btn2',
				'type'       => 'text',
			) );
			$slider->add_field( array(
				'name'       => esc_html__( 'Button url 2', 'dreamhub' ),
				'desc'       => esc_html__( 'insert button text url here', 'dreamhub' ),
				'id'         => $prefix . 'em_slide_btn2url',
				'type'       => 'text_url',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Button Animate','dreamhub'),
				'id'      => $prefix . 'em_aimate_btn',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'dreamhub' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'dreamhub' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'dreamhub' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'dreamhub' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'dreamhub' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'dreamhub' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'dreamhub' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'dreamhub' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'dreamhub' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'dreamhub' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'dreamhub' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'dreamhub' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'dreamhub' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'dreamhub' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'dreamhub' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'dreamhub' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'dreamhub' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'dreamhub' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'dreamhub' ),				
					'rollIn' => esc_html__( 'rollIn', 'dreamhub' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'dreamhub' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'dreamhub' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'dreamhub' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'dreamhub' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'dreamhub' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'dreamhub' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'dreamhub' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'dreamhub' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'dreamhub' ),				
				),
				'default' =>'bounceInUp',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Button Animate Duration','dreamhub'),
				'id'      => $prefix . 'em_durations_btn',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'3',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Button Animate Delay','dreamhub'),
				'id'      => $prefix . 'em_dealy_btn',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'dreamhub' ),							
					'0.1' => esc_html__( 'point 1s', 'dreamhub' ),							
					'0.2' => esc_html__( 'point 2s', 'dreamhub' ),							
					'0.3' => esc_html__( 'point 3s', 'dreamhub' ),							
					'0.4' => esc_html__( 'point 4s', 'dreamhub' ),							
					'0.5' => esc_html__( 'point 5s', 'dreamhub' ),							
					'0.6' => esc_html__( 'point 6s', 'dreamhub' ),							
					'0.7' => esc_html__( 'point 7s', 'dreamhub' ),							
					'0.8' => esc_html__( 'point 8s', 'dreamhub' ),							
					'0.9' => esc_html__( 'point 9s', 'dreamhub' ),							
					'1.2' => esc_html__( '1 point 2s', 'dreamhub' ),							
					'1.3' => esc_html__( '1 point 3s', 'dreamhub' ),							
					'1.4' => esc_html__( '1 point 4s', 'dreamhub' ),							
					'1.5' => esc_html__( '1 point 5s', 'dreamhub' ),							
					'1.8' => esc_html__( '1 point 8s', 'dreamhub' ),							
					'2' => esc_html__( '2s', 'dreamhub' ),							
					'2.2' => esc_html__( '2 point 2s', 'dreamhub' ),							
					'2.3' => esc_html__( '2 point 5s', 'dreamhub' ),							
					'3' => esc_html__( '3s', 'dreamhub' ),							
				),
				'default' =>'1',
			) );				
			$slider->add_field( array(
				'name'    => esc_html__('Text Alignment Style','dreamhub'),
				'id'      => $prefix . 'em_slider_posi',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'' => esc_html__( 'Select alignment', 'dreamhub' ),
					'text-left' => esc_html__( 'Left Alignment', 'dreamhub' ),
					'text-center' => esc_html__( 'Center Alignment', 'dreamhub' ),
					'text-right' => esc_html__( 'Right Alignment', 'dreamhub' ),
				),
				'default' =>'text-center',
			) );				
			$slider->add_field( array(
				'name'       => esc_html__( 'More Sliders Option, Please see slider widget area', 'dreamhub' ),
				'id'         => $prefix . 'title_heading_line',
				'type'       => 'title',
			) );
			
	}
	add_action( 'cmb2_admin_init', 'dreamhub_metabox' );