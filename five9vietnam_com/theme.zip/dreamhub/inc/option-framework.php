<?php
/**
 * ReduxFramework Barebones Sample Config File
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

if ( ! class_exists( 'Redux' ) ) {
	return null;
}

// This is your option name where all the Redux data is stored.
$opt_name = 'dreamhub_opt';

/**
 * GLOBAL ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: @link https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 */

/**
 * ---> BEGIN ARGUMENTS
 */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
	// REQUIRED!!  Change these values as you need/desire.
	'opt_name'                  => $opt_name,

	// Name that appears at the top of your panel.
	'display_name'              => $theme->get( 'Name' ),

	// Version that appears at the top of your panel.
	'display_version'           => $theme->get( 'Version' ),

	// Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only).
	'menu_type'                 => 'menu',

	// Show the sections below the admin menu item or not.
	'allow_sub_menu'            => true,

	'menu_title'                => esc_html__( 'Dreamhub Options', 'dreamhub' ),
	'page_title'                => esc_html__( 'Dreamhub Options', 'dreamhub' ),

	// Disable this in case you want to create your own google fonts loader.
	'disable_google_fonts_link' => false,

	// Show the panel pages on the admin bar.
	'admin_bar'                 => true,

	// Choose an icon for the admin bar menu.
	'admin_bar_icon'            => 'dashicons-portfolio',

	// Choose an priority for the admin bar menu.
	'admin_bar_priority'        => 50,

	// Set a different name for your global variable other than the opt_name.
	'global_variable'           => '',

	// Show the time the page took to load, etc.
	'dev_mode'                  => true,

	// Enable basic customizer support.
	'customizer'                => true,

	// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
	'page_priority'             => 90,

	// For a full list of options, visit: @link http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters.
	'page_parent'               => 'themes.php',

	// Permissions needed to access the options panel.
	'page_permissions'          => 'manage_options',

	// Specify a custom URL to an icon.
	'menu_icon'                 => '',

	// Force your panel to always open to a specific tab (by id).
	'last_tab'                  => '',

	// Icon displayed in the admin panel next to your menu_title.
	'page_icon'                 => 'icon-themes',

	// Page slug used to denote the panel.
	'page_slug'                 => '_options',

	// On load save the defaults to DB before user clicks save or not.
	'save_defaults'             => true,

	// If true, shows the default value next to each field that is not the default value.
	'default_show'              => false,

	// What to print by the field's title if the value shown is default. Suggested: *.
	'default_mark'              => '',

	// Shows the Import/Export panel when not used as a field.
	'show_import_export'        => true,

	// CAREFUL -> These options are for advanced use only.
	'transient_time'            => 60 * MINUTE_IN_SECONDS,

	// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output.
	'output'                    => true,

	// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head.
	'output_tag'                => true,

	// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
	// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
	'database'                  => '',

	// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
	'use_cdn'                   => true,
	'compiler'                  => true,

	// Enable or disable flyout menus when hovering over a menu with submenus.
	'flyout_submenus'           => true,

	// Mode to display fonts (auto|block|swap|fallback|optional)
	// See: https://developer.mozilla.org/en-US/docs/Web/CSS/@font-face/font-display
	'font_display'              => 'swap',

	// HINTS.
	'hints'                     => array(
		'icon'          => 'el el-question-sign',
		'icon_position' => 'right',
		'icon_color'    => 'lightgray',
		'icon_size'     => 'normal',
		'tip_style'     => array(
			'color'   => 'light',
			'shadow'  => true,
			'rounded' => false,
			'style'   => '',
		),
		'tip_position'  => array(
			'my' => 'top left',
			'at' => 'bottom right',
		),
		'tip_effect'    => array(
			'show' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'mouseover',
			),
			'hide' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'click mouseleave',
			),
		),
	),
);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['admin_bar_links'][] = array(
	'id'    => 'redux-docs',
	'href'  => '//devs.redux.io/',
	'title' => esc_html__( 'Documentation', 'dreamhub' ),
);

$args['admin_bar_links'][] = array(
	'id'    => 'redux-support',
	'href'  => '//github.com/ReduxFramework/redux-framework/issues',
	'title' => esc_html__( 'Support', 'dreamhub' ),
);

$args['admin_bar_links'][] = array(
	'id'    => 'redux-extensions',
	'href'  => 'redux.io/extensions',
	'title' => esc_html__( 'Extensions', 'dreamhub' ),
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
	'url'   => '//github.com/ReduxFramework/ReduxFramework',
	'title' => 'Visit us on GitHub',
	'icon'  => 'el el-github',
);
$args['share_icons'][] = array(
	'url'   => '//www.facebook.com/pages/Redux-Framework/243141545850368',
	'title' => esc_html__( 'Like us on Facebook', 'dreamhub' ),
	'icon'  => 'el el-facebook',
);
$args['share_icons'][] = array(
	'url'   => '//twitter.com/reduxframework',
	'title' => esc_html__( 'Follow us on Twitter', 'dreamhub' ),
	'icon'  => 'el el-twitter',
);
$args['share_icons'][] = array(
	'url'   => '//www.linkedin.com/company/redux-framework',
	'title' => esc_html__( 'FInd us on LinkedIn', 'dreamhub' ),
	'icon'  => 'el el-linkedin',
);

// Panel Intro text -> before the form.
if ( ! isset( $args['global_variable'] ) || false !== $args['global_variable'] ) {
	if ( ! empty( $args['global_variable'] ) ) {
		$v = $args['global_variable'];
	} else {
		$v = str_replace( '-', '_', $args['opt_name'] );
	}
	$args['intro_text'] = '<p>' . sprintf( __( 'Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: $s', 'dreamhub' ) . '</p>', '<strong>' . $v . '</strong>' );
} else {
	$args['intro_text'] = '<p>' . esc_html__( 'This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.', 'dreamhub' ) . '</p>';
}

// Add content after the form.
$args['footer_text'] = '<p>' . esc_html__( 'This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.', 'dreamhub' ) . '</p>';

Redux::set_args( $opt_name, $args );

/*
 * ---> END ARGUMENTS
 */

/*
 * ---> BEGIN HELP TABS
 */

$help_tabs = array(
	array(
		'id'      => 'redux-help-tab-1',
		'title'   => esc_html__( 'Theme Information 1', 'dreamhub' ),
		'content' => '<p>' . esc_html__( 'This is the tab content, HTML is allowed.', 'dreamhub' ) . '</p>',
	),

	array(
		'id'      => 'redux-help-tab-2',
		'title'   => esc_html__( 'Theme Information 2', 'dreamhub' ),
		'content' => '<p>' . esc_html__( 'This is the tab content, HTML is allowed.', 'dreamhub' ) . '</p>',
	),
);

Redux::set_help_tab( $opt_name, $help_tabs );

// Set the help sidebar.
$content = '<p>' . esc_html__( 'This is the sidebar content, HTML is allowed.', 'dreamhub' ) . '</p>';
Redux::set_help_sidebar( $opt_name, $content );

/*
 * <--- END HELP TABS
 */

/*
 *
 * ---> BEGIN SECTIONS
 *
 */

/* As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for. */


/* -> START Header Area. */

$section = array(
	'title'  => esc_html__( 'Head', 'dreamhub' ),
	'id'     => 'header',
	'icon'   => 'el el-home',
	'fields' => array(
		array(
			'id'       => 'header_top_toggle',
			'type'     => 'switch',
			'title'    => esc_html__( 'Top Bar Show/Hide', 'dreamhub' ),
			'subtitle' => esc_html__('If you ON this section, it will show header top section all your single page.', 'dreamhub'),
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title' => __( 'Header', 'dreamhub' ),
	'id'    => 'header',
	'desc'  => __( 'These are global settings for Header. You can change the setting for each page separately if you wish.', 'dreamhub' ),
	'icon'  => 'el el-asterisk',
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Header Top', 'dreamhub' ),
	'id'         => 'header_top',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'top_phone',
			'type'     => 'text',
			'title'    => esc_html__( 'Phone Number', 'dreamhub' ),
			'desc'     => esc_html__( 'Insert phone number', 'dreamhub' ),
			'default'     => esc_html__( '+880 320 432 242', 'dreamhub' ),
		),
		array(
			'id'       => 'top_link1_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Link 1 Text', 'dreamhub' ),
			'default'     => esc_html__( 'Click Here', 'dreamhub' ),
		),
		array(
			'id'       => 'top_link1_url',
			'type'     => 'text',
			'title'    => esc_html__( 'Link 1 URL', 'dreamhub' ),
			'desc'     => esc_html__( 'Insert URL/Page link', 'dreamhub' ),
			'default'     => esc_html__( '#', 'dreamhub' ),
		),
		array(
			'id'       => 'top_link2_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Link 2 Text', 'dreamhub' ),
			'default'     => esc_html__( 'Click Here', 'dreamhub' ),
		),
		array(
			'id'       => 'top_link2_url',
			'type'     => 'text',
			'title'    => esc_html__( 'Link 2 URL', 'dreamhub' ),
			'desc'     => esc_html__( 'Insert URL/Page link', 'dreamhub' ),
			'default'     => esc_html__( '#', 'dreamhub' ),
		),
		array(
            'id'       => 'top_social_icons',
            'type'     => 'sortable',
            'title'    => esc_html__('Insert Social Icons', 'dreamhub'),
            'subtitle' => esc_html__('Enter social links', 'dreamhub'),
            'mode'     => 'text',
			'label'    => true,
            'options'  => array(
                'facebook'     => '',
                'twitter'      => '',
                'instagram'    => '',
                'tumblr'       => '',
                'pinterest'    => '',
                'linkedin'     => '',
                'behance'      => '',
                'dribbble'     => '',
                'youtube'      => '',
                'vimeo'        => '',
                'rss'          => '',
            ),
			'default' => array(
				'facebook'     => esc_url('https://www.facebook.com/'),
				'twitter'     => esc_url('https://twitter.com/'),
				'instagram'	=> esc_url('https://instagram.com/'),
				'tumblr'     => '',
				'pinterest'     => '',
				'linkedin'     => '',
				'behance'     => '',
				'dribbble'     => esc_url('https://dribbble.com/'),
				'youtube'     => '',
				'vimeo'     => '',
				'rss'     => '',
			),
		),
		array(
			'id'          => 'top-left-typography',
			'type'        => 'typography', 
			'title'       => __('Top Left Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.site-header .top-bar .text-wrapper .text-left span, .site-header .top-bar .text-wrapper .text-left a, .site-header .top-bar .text-wrapper .text-left i'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'dreamhub'),
		),
	    array(         
	        'id'       => 'top-background',
	        'type'     => 'background',
	        'title'    => __('Top Bar Background', 'dreamhub'),
	        'subtitle' => __('Top Bar background with image, color, etc.', 'dreamhub'),
	        'output'    => array('.site-header .top-bar'),
	    ),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Header Logo', 'dreamhub' ),
	'id'         => 'header_logo',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'default_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Default Logo', 'dreamhub' ),
			'desc'     => esc_html__( 'Upload logo here.ex: - it is work in default menu.', 'dreamhub' ),
		),
		array(
			'id'       => 'transparent_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Transparent Menu Logo', 'dreamhub' ),
			'desc'     => esc_html__( 'Upload logo here.ex: - it is work in transparent menu.', 'dreamhub' ),
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Header Menu', 'dreamhub' ),
	'id'         => 'dreamhub_menu',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'button_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Button Text', 'dreamhub' ),
			'default'  => 'Click Here',
		),
		array(
			'id'       => 'button_link',
			'type'     => 'text',
			'title'    => esc_html__( 'Button Link', 'dreamhub' ),
			'default'  => 'your-domain.com',
		),
		array(
			'id'        => 'menu_link_color',
			'type'      => 'color',
			'title'     => esc_html__('Link Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-header .manu-wrapper .nav-menu li a',
			)
		),
		array(
			'id'        => 'menu_link_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Link Hover Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-header .manu-wrapper .nav-menu li a:hover',
			)
		),
		array(
			'id'        => 'menu_button_color',
			'type'      => 'color',
			'title'     => esc_html__('Menu Button & Search Text Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-header .main-menu .main-navigation .header-nav .menu-button a, .site-header .main-menu .main-navigation .header-nav .search i'
			)
		),
		array(
			'id'        => 'menu_button_bg',
			'type'      => 'color',
			'title'     => esc_html__('Menu Button & Search BG Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'background-color' => '.site-header .main-menu .main-navigation .header-nav .menu-button a, .site-header .main-menu .main-navigation .header-nav .search i',
			)
		),
		array(
			'id'        => 'dreamhub_menu_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Section BG Color', 'dreamhub'),
			'default'  => '',
			'output'    => array('
				.site-header .main-menu
			'),
			'default'  => array(
				'background-color' => '',
			)
		),
		array(
			'id'        => 'submenu_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Sub Menu BG Color', 'dreamhub'),
			'default'  => '',
			'output'    => array('
				.dreamhub_menu ul .sub-menu
			'),
			'default'  => array(
				'background-color' => '',
			)					
		),
		array(
			'id'             => 'menu_spacing',
			'type'           => 'spacing',
			'output'         => array('.site-header .main-menu'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Section Padding Option', 'dreamhub'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'dreamhub'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),

	),
);

Redux::set_section( $opt_name, $section );

/* <- END Header Area. */


/* -> START Typography. */

$section = array(
	'title'  => esc_html__( 'Typography', 'dreamhub' ),
	'id'     => 'typography',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'          => 'dreamhub_body_typography',
			'type'        => 'typography', 
			'title'       => esc_html__('Body Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'line-height'   => false,
			'output'      => array('body'),
			'units'       =>'px',
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '',						
			),
		),
				array(
					'id'          => 'dreamhub_heading_typographyh1',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H1', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h1				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'dreamhub_heading_typographyh2',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H2', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h2				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'dreamhub_heading_typographyh3',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H3', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h3			
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'dreamhub_heading_typographyh4',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H4', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h4				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'dreamhub_heading_typographyh5',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H5', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h5					
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'dreamhub_heading_typographyh6',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H6', 'dreamhub'),
					'google'      => true, 
					'font-backup' => true,
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h6					
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'dreamhub'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',			
					),
				),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Typography. */

/* -> START Breadcrumb Area. */

$section = array(
	'title'  => esc_html__( 'Bredcrumb Area', 'dreamhub' ),
	'id'     => 'breadcrumb',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => 'breadcrumb-background',
			'type'     => 'background',
			'title'    => __('Breadcrumb Background', 'dreamhub'),
			'output'    => array('.breadcumb-area'),
		),

		array(
			'id'          => 'breadcrumb-title-typography',
			'type'        => 'typography', 
			'title'       => __('Title Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.breadcumb-area .text-wrapper h2'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'dreamhub'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),

		array(
			'id'        => 'dreamhub_bread_current_page_color',
			'type'      => 'color',
			'title'     => esc_html__('Breadcrumb Current Text Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.breadcumb-area .text-wrapper ul li:nth-last-child(-n+1)'
			)
		),
		array(
			'id'             => 'breadcrumb_spacing',
			'type'           => 'spacing',
			'output'         => array('.breadcumb-area'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'dreamhub'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'dreamhub'),
			'default'            => array(
				'padding-top'     => '',
				'padding-right'   => '',
				'padding-bottom'  => '',
				'padding-left'    => '',
				'units'          => 'px',
			)
		),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Breadcrumb Area. */

/* -> START Blog Details page */

$section = array(
	'title'  => esc_html__( 'Blog Details', 'dreamhub' ),
	'id'     => 'blog_details',
	'desc'  => __( 'This changes will affect the blog details page', 'dreamhub' ),
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => 'blog_details_background',
			'type'     => 'background',
			'title'    => __('Page Background', 'dreamhub'),
			'default'	=> array(
				'background' => '',
			),
			'output'    => array('.blog-details'),
		),
		array(
			'id'          => 'blog_details_meta_typography',
			'type'        => 'typography', 
			'title'       => __('Meta Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details .post .blog-content .entry-meta, .blog-details .post .blog-content .entry-meta a, .blog-details .post .blog-content .entry-meta span'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'dreamhub'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),
		array(
			'id'          => 'blog_details_content_typography',
			'type'        => 'typography', 
			'title'       => __('Content Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details .blog-content .entry-content p'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'dreamhub'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),
		$field = array(
			'id'       => 'blog_details_tag_bg',
			'type'     => 'color',
			'title'    => __('Tags & Icons Hover Background Color', 'dreamhub'), 
			'output'      => array('background-color' => '.blog-details .post .blog-content .entry-footer .post-tags a:hover, .blog-details .post .blog-content .entry-footer .social-share ul li a:hover',
				'border-color' => '.blog-details .post .blog-content .entry-footer .post-tags a:hover, .blog-details .post .blog-content .entry-footer .social-share ul li a:hover'),
			'validate' => 'color',
		),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Blog Details Page */

/* -> START Sidebar */

$section = array(
	'title'  => esc_html__( 'Sidebar', 'dreamhub' ),
	'id'     => 'sidebar',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'          => 'sidebar_title_typography',
			'type'        => 'typography', 
			'title'       => __('Title Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.widget-area .widget h2'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'dreamhub'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Sidebar */

/* -> START 404 page */

$section = array(
	'title'  => esc_html__( '404 Page', 'dreamhub' ),
	'id'     => '404_page',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => '404_background',
			'type'     => 'background',
			'title'    => __('Page Background', 'dreamhub'),
			'default'	=> array(
				'background' => '',
			),
			'output'    => array('.four-zero-four'),
		),
		array(
			'id'          => '404_title_typography',
			'type'        => 'typography', 
			'title'       => esc_html__('Title Typography', 'dreamhub'),
			'google'      => true, 
			'font-backup' => true,					
			'output'      => array('.four-zero-four .error-404 h1'),
			'units'       =>'px',
			'default'     => array(
				'color'       => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '',						
			),
		),
		array(
			'id'       => '404_info',
			'type'     => 'editor',
			'title'    => __('404 Information', 'dreamhub'),
			'subtitle'    => __('HTML tags allowed: a, br, em, strong', 'dreamhub'),
			'default'	=> esc_html__('Oops! That page can’t be found.', 'dreamhub'),
		),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END 404 Page */



/* -> START Footer Section. */

$section = array(
	'title'  => esc_html__( 'Basic Field', 'dreamhub' ),
	'id'     => 'footer',
	'desc'   => esc_html__( 'Basic field with no subsections.', 'dreamhub' ),
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => 'footer_widget_toggle',
			'type'     => 'switch',
			'title'    => esc_html__( 'Widget Area Show/Hide', 'dreamhub' ),
			'subtitle' => esc_html__('If you ON this section, it will show footer widgets all your single page.', 'dreamhub'),
			'default'  => true,
		),
		array(
			'id'        => 'footer_bg',
			'type'      => 'background',
			'title'     => esc_html__('Footer Background', 'dreamhub'),
			'default'  => '',
			'output'    => array('.site-footer'),
			'default'  => array(
				'background-color' => '',
			)					
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title' => __( 'Footer', 'dreamhub' ),
	'id'    => 'footer',
	'icon'  => 'el el-asterisk',
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Widget Area', 'dreamhub' ),
	'id'         => 'opt-widget-subsection',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'        => 'widget_column_count',
			'type'      => 'select',
			'title'     => esc_html__('Widget Column Count', 'dreamhub'),
			'customizer_only'   => false,
			'options'   => array(
				'1' => esc_html__('Column 1','dreamhub'),
				'2' => esc_html__('Column 2','dreamhub'),
				'3' => esc_html__('Column 3','dreamhub'),
				'4' => esc_html__('Column 4','dreamhub'),
				'6' => esc_html__('Column 6','dreamhub'),
			),
			'default'   =>'4'
		),
		array(	
			'id'        => 'widget_title_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Title Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget-title'
			)
		),
		array(								
			'id'        => 'widget_text_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Text Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget ul li a,
				.site-footer .footer-widget .widget p,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text h4 a,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text .rcomment'
			)
		),
		array(
			'id'        => 'widget_link_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Link Hover Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget ul li a:hover,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text h4 a:hover'
			)
		),
		array(
			'id'        => 'dreamhub_widget_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Widget Section BG', 'dreamhub'),
			'default'  => '',
			'output'    => array('.site-footer .footer-widget'),
			'default'  => array(
				'background-color' => '',
			)					
		),
		array(
			'id'             => 'dreamhub_widget_section_spacing',
			'type'           => 'spacing',
			'output'         => array('.site-footer .footer-widget'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'dreamhub'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'dreamhub'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Copyright Area', 'dreamhub' ),
	'id'         => 'copyright_subsection',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'        => 'footer_copyright_style',
			'type'      => 'select',
			'title'     => esc_html__('Copyright Style Layout', 'dreamhub'),
			'customizer_only'   => false,
			'options'   => array(
				'copy_s1' => esc_html__('Centered copyright text','dreamhub'),
				'copy_s2' => esc_html__('Left Text and Right Menu','dreamhub'),
				
			),
		),
		array(
			'id'        => 'copyright-text',
			'type'      => 'editor',
			'title'     => esc_html__('Copyright information', 'dreamhub'),
			'subtitle'  => esc_html__('HTML tags allowed: a, br, em, strong', 'dreamhub'),
			'default'	=> esc_html__('Copyright &copy; dreamhub all rights reserved.', 'dreamhub'),
			'args'      => array(
				'teeny'            => true,
				'textarea_rows'    => 5,
				'media_buttons' => false,
			)
		),
		array(								
			'id'        => 'dreamhub_copyright_text_color',
			'type'      => 'color',
			'title'     => esc_html__('Copyright Text Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .copyright .copyright-text p, .site-footer .copyright .copyright-menu ul li a'
			)
		),
		array(
			'id'        => 'dreamhub_copyright_text_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Copyright Text Hover Color', 'dreamhub'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .copyright .copyright-text p:hover, .site-footer .copyright .copyright-menu ul li a:hover'
			)
		),
		array(
			'id'        => 'dreamhub_copyright_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Copyright Section BG', 'dreamhub'),
			'default'  => '',
			'output'    => array('
				.copyright
			'),
			'default'  => array(
				'background-color' => '',
			)
		),
		array(
			'id'             => 'copyright_section_spacing',
			'type'           => 'spacing',
			'output'         => array('.site-footer .copyright'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'dreamhub'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'dreamhub'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),

	),
);

Redux::set_section( $opt_name, $section );

/*
 * <--- END SECTIONS
 */

