<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package dreamhub
 */

get_header();
?>

	<?php

	$show_breadcumb  = get_post_meta( get_the_ID(),'_dreamhub_breadcrumbs', true );
	$breadcrumb_title  = get_post_meta( get_the_ID(),'_dreamhub_breadcrumb_title', true );
	$bg_image  = get_post_meta( get_the_ID(),'_dreamhub_bg_image', true );
	$page_text_transform  = get_post_meta( get_the_ID(),'_dreamhub_page_text_transform', true );

	?>

	<?php if( $show_breadcumb == 0 ){ ?>
	<div class="breadcumb-area" <?php if($bg_image){?> style="background-image:url(<?php echo esc_url($bg_image)?>)" <?php } ?>>
		<div class="container">
			<div class="text-wrapper">
				<?php if( $breadcrumb_title == 'show_title' ) { ?>
				<h2 <?php if($page_text_transform){?> style="text-transform:<?php echo $page_text_transform?>" <?php } ?> ><?php wp_title(''); ?></h2>
				<?php } ?>

				<?php dreamhub_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<?php } ?>

	<div class="default-page">
		
		<main id="primary" class="site-main">

			<?php
			while ( have_posts() ) : the_post();

				the_content();

			endwhile;
			?>

		</main>

	</div>

<?php

get_footer();
