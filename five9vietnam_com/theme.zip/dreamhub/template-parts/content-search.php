<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package dreamhub
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="blog-thumb">
		<?php dreamhub_post_thumbnail(); ?>
	</div>

	<div class="blog-content">
		<div class="entry-header">

			<?php if ( 'post' === get_post_type() ) : ?>
				<div class="entry-meta">
					<a class="author" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
					<span><?php echo get_the_time(get_option('date_format')); ?></span>
					<a class="meta_comments" href="<?php comments_link(); ?>">
						<?php comments_number( esc_html__('0 Comments','dreamhub'), esc_html__('1 Comments','dreamhub'), esc_html__('% Comments','dreamhub') );?>
					</a>
				</div>
			<?php endif; ?>

			<?php
			if ( is_singular() ) :
				the_title( '<h1 class="entry-title">', '</h1>' );
			else :
				the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
			endif; ?>

		</div>

		<div class="entry-content">
			<?php

			the_excerpt();

			wp_link_pages(
				array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'dreamhub' ),
					'after'  => '</div>',
				)
			);
			?>
		</div>
	</div>

</article>