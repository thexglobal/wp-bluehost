
<div id="live-preview" class="default" style="margin-left: -202px;">   
   <div id="live-preview-admin">
		<h5>Style Switcher</h5>
		<div class="live-preview-admin-box">
			<div>
				<p class="title">Main Layout</p>
				<div class="area">
					<ul id="tootlbar_boxed" class="choose_option">
						<li class="full-width" data-value=""><div class="box fullwidth"></div>Full Width</li>
						<li class="boxed" data-value="boxed"><div class="box contained"></div>Boxed</li>
						
					</ul>
				</div>
				
				<p class="title border">Primary Color</p>
				<div class="area">
					<div id="tootlbar_colors">
						<ul>
							<li><div class="color active" data-color="blue" style="background-color:#24A3D8;"></div></li>
							<li><div class="color color2" data-color="red" style="background-color:#d94707;"></div></li>
							<li><div class="color color4" data-color="green" style="background-color:#59a148;"></div></li>
							<li><div class="color color4" data-color="purple" style="background-color:#8572a4;"></div></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a class="open" href="#"><span><i class="fa fa-cogs"></i></span></a>
</div>